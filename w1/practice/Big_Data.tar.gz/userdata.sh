#!/bin/bash

echo "Enter first name: "
read fname
echo "Enter last name: "
read lname
echo "Enter email: "
read umail
echo "Enter username: "
read uname
echo "Enter password: "
read pw
echo "Whats your fav color? :D"
read favcolor
echo "$fname, $lname, $uname, $umail, $pw, $favcolor" >> getdata.csv